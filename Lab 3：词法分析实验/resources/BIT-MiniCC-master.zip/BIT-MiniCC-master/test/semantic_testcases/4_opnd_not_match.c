int main()
{
	int a = 2;
	double b = 3.5;
	int res = a<<b;
	return 0;
}