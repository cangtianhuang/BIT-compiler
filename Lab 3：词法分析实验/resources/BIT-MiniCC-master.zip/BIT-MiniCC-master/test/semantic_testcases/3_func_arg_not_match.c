int f(int a,int b){
	return a+b;
}
int main(){
	int res = f(1);
	res = f(1,0.2);
	return 0;
}