int main()
{
	break;
	
	for(;;){
		break;
	}
	
	break;
	
	return 0;
}