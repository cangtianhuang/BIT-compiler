//int f();
int main()
{
	int res = f();
	int c = a+1;
	return 0;
}
int f(){
	return 1;
}