int f();
//int f();
int f(){
	return 1;
}

int f(){
	return 2;
}

int main()
{
	int a;
	int a;
	
	int b;
	{
		int b;
	}
	return 0;
}