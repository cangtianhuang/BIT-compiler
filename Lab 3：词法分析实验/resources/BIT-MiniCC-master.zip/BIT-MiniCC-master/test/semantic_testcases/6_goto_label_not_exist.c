int main()
{
k1:
	goto k2;
k2:
	goto k1;
	
	goto end;
	return 0;
}