int main()
{
	int a,b,c;
}

int f(){
	return 1;
}