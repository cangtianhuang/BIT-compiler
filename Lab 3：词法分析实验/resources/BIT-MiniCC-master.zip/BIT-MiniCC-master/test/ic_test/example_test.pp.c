int main() {
	int a, b, c;
	a = 0;
	b = 1;
	c = 2;
	c = a + b + (c + 3);
	return 0;
}
