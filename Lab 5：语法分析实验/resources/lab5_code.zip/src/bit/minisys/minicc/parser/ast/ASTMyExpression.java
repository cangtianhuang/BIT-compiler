package bit.minisys.minicc.parser.ast;

import java.util.LinkedList;

import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("ASTMyExpression")
public class ASTMyExpression extends ASTExpression {

	public String specifiedType;
	public LinkedList<ASTExpression> exprs;
	public LinkedList<ASTToken> ops;

	public ASTMyExpression(String type) {
		super(type);
		this.specifiedType = type;
		this.exprs = new LinkedList<ASTExpression>();
		this.ops = new LinkedList<ASTToken>();
	}

	@Override
	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}
