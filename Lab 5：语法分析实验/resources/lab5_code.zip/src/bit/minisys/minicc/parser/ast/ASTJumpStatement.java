package bit.minisys.minicc.parser.ast;

import com.fasterxml.jackson.annotation.JsonTypeName;

@JsonTypeName("JumpStatement")
public class ASTJumpStatement extends ASTStatement {
	public ASTToken token;
	public ASTExpression expr;
	public ASTStatement stat;

	public ASTJumpStatement() {
		super("JumpStatement");
	}

	@Override
	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}
}
