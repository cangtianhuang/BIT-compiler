package bit.minisys.minicc.parser;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import org.antlr.v4.gui.TreeViewer;

import com.fasterxml.jackson.databind.ObjectMapper;

import bit.minisys.minicc.MiniCCCfg;
import bit.minisys.minicc.internal.util.MiniCCUtil;
import bit.minisys.minicc.parser.ast.ASTBreakStatement;
import bit.minisys.minicc.parser.ast.ASTCastExpression;
import bit.minisys.minicc.parser.ast.ASTCharConstant;
import bit.minisys.minicc.parser.ast.ASTCompilationUnit;
import bit.minisys.minicc.parser.ast.ASTCompoundStatement;
import bit.minisys.minicc.parser.ast.ASTConditionExpression;
import bit.minisys.minicc.parser.ast.ASTContinueStatement;
import bit.minisys.minicc.parser.ast.ASTDeclaration;
import bit.minisys.minicc.parser.ast.ASTExpression;
import bit.minisys.minicc.parser.ast.ASTExpressionStatement;
import bit.minisys.minicc.parser.ast.ASTFloatConstant;
import bit.minisys.minicc.parser.ast.ASTFunctionDeclarator;
import bit.minisys.minicc.parser.ast.ASTFunctionDefine;
import bit.minisys.minicc.parser.ast.ASTGotoStatement;
import bit.minisys.minicc.parser.ast.ASTIdentifier;
import bit.minisys.minicc.parser.ast.ASTInitList;
import bit.minisys.minicc.parser.ast.ASTIntegerConstant;
import bit.minisys.minicc.parser.ast.ASTIterationStatement;
import bit.minisys.minicc.parser.ast.ASTJumpStatement;
import bit.minisys.minicc.parser.ast.ASTLabeledStatement;
import bit.minisys.minicc.parser.ast.ASTMyExpression;
import bit.minisys.minicc.parser.ast.ASTMyNode;
import bit.minisys.minicc.parser.ast.ASTNode;
import bit.minisys.minicc.parser.ast.ASTParamsDeclarator;
import bit.minisys.minicc.parser.ast.ASTPostfixExpression;
import bit.minisys.minicc.parser.ast.ASTReturnStatement;
import bit.minisys.minicc.parser.ast.ASTSelectionStatement;
import bit.minisys.minicc.parser.ast.ASTStatement;
import bit.minisys.minicc.parser.ast.ASTStringConstant;
import bit.minisys.minicc.parser.ast.ASTToken;
import bit.minisys.minicc.parser.ast.ASTTypename;
import bit.minisys.minicc.parser.ast.ASTUnaryExpression;
import bit.minisys.minicc.parser.ast.ASTVariableDeclarator;

/*
 * PROGRAM --> EXTERNAL_DECLARATION_LIST
 * EXTERNAL_DECLARATION_LIST --> EXTERNAL_DECLARATION EXTERNAL_DECLARATION_LIST | e
 * EXTERNAL_DECLARATION --> FUNCTION_DEFINITION | DECLARATION
 * 
 * FUNCTION_DEFINITION --> DECLARATION_SPECIFIERS DECLARATOR '(' PARAMETER_LIST ')' COMPOUND_STATEMENT
 * 
 * DECLARATION_SPECIFIERS --> DECLARATION_SPECIFIER DECLARATION_SPECIFIERS | DECLARATION_SPECIFIER
 * DECLARATION_SPECIFIER --> STORAGE_CLASS_SPECIFIER | TYPE_SPECIFIER | TYPE_QUALIFIER | FUNCTION_SPECIFIER
 * STORAGE_CLASS_SPECIFIER --> TYPEDEF | EXTERN | STATIC | AUTO
 * TYPE_SPECIFIER --> VOID | CHAR | SHORT | INT | LONG | FLOAT | DOUBLE | SIGNED | UNSIGNED | BOOL
 * TYPE_QUALIFIER --> CONST | RESTRICT | VOLATILE
 * FUNCTION_SPECIFIER --> INLINE
 * 
 * DECLARATOR --> POINTER IDENTIFIER | IDENTIFIER
 * POINTER --> '*' TYPE_QUALIFIER_LIST POINTER| '*' TYPE_QUALIFIER_LIST | '*' POINTER | '*'
 * TYPE_QUALIFIER_LIST --> TYPE_QUALIFIER TYPE_QUALIFIER_LIST | TYPE_QUALIFIER
 * 
 * PARAMETER_LIST --> PARAMETER_DECLARATION ',' PARAMETER_LIST | PARAMETER_DECLARATION | e
 * PARAMETER_DECLARATION --> DECLARATION_SPECIFIERS DECLARATOR
 * 
 * DECLARATION --> DECLARATION_SPECIFIERS INIT_DECLARATOR_LIST ';'
 * INIT_DECLARATOR_LIST	--> INIT_DECLARATOR ',' INIT_DECLARATOR_LIST | INIT_DECLARATOR
 * INIT_DECLARATOR --> DECLARATOR '=' INITIALIZER | DECLARATOR
 * INITIALIZER --> ASSIGNMENT_EXPRESSION | '{' INITIALIZER_LIST '}'
 * INITIALIZER_LIST --> INITIALIZER ',' INITIALIZER_LIST | INITIALIZER ',' | INITIALIZER
 * 
 * COMPOUND_STATEMENT --> '{' BLOCK_ITEM_LISTopt '}'
 * BLOCK_ITEM_LIST --> BLOCK_ITEM | BLOCK-ITEM BLOCK_ITEM_LIST
 * BLOCK_ITEM --> DECLARATION | STATEMENT
 * 
 * STATEMENT --> LABELED_STATEMENT | COMPOUND_STATEMENT | EXPRESSION_STATEMENT | SELECTION_STATEMENT | ITERATION_STATEMENT | JUMP_STATEMENT
 * LABELED_STATEMENT --> IDENTIFIER ':' STATEMENT | CASE CONDITIONAL_EXPRESSION ':' STATEMENT | DEFAULT ':' STATEMENT
 * EXPRESSION_STATEMENT --> EXPRESSIONOPT ';'
 * SELECTION_STATEMENT --> IF '(' EXPRESSION ')' STATEMENT | IF '(' EXPRESSION ')' STATEMENT ELSE STATEMENT | SWITCH '(' EXPRESSION ')' STATEMENT
 * ITERATION_STATEMENT --> WHILE '(' EXPRESSION ')' STATEMENT | DO STATEMENT WHILE '(' EXPRESSION ')' ';'
 *     | FOR '(' EXPRESSIONopt ';' EXPRESSIONopt ';' EXPRESSIONopt ')' STATEMENT | FOR '(' DECLARATION EXPRESSIONopt ';' EXPRESSIONopt ')' STATEMENT 
 * JUMP_STATEMENT --> GOTO IDENTIFIER ';' | CONTINUE ';' | BREAK ';' | RETURN EXPRESSIONopt ';'
 * 
 * EXPRESSION --> ASSIGNMENT-EXPRESSION | ASSIGNMENT-EXPRESSION ',' EXPRESSION
 * ASSIGNMENT_EXPRESSION --> CONDITIONAL_EXPRESSION | UNARY_EXPRESSION ASSIGNMENT_OPERATOR ASSIGNMENT_EXPRESSION
 * ASSIGNMENT_OPERATOR --> '=' | '*=' | '/=' | '%=' | '+=' | '-=' | '<<=' | '>>=' | '&=' | '^=' | '|='
 * CONDITIONAL_EXPRESSION --> LOGICAL_OR_EXPRESSION | LOGICAL_OR_EXPRESSION ? EXPRESSION : CONDITIONAL_EXPRESSION

 * LOGICAL_OR_EXPRESSION --> LOGICAL_AND_EXPRESSION | LOGICAL_AND_EXPRESSION '||' LOGICAL_OR_EXPRESSION
 * LOGICAL_AND_EXPRESSION --> INCLUSIVE_OR_EXPRESSION | INCLUSIVE_OR_EXPRESSION '&&' LOGICAL_AND_EXPRESSION
 * EXCLUSIVE_OR_EXPRESSION --> AND_EXPRESSION | AND_EXPRESSION '^' EXCLUSIVE_OR_EXPRESSION
 * AND_EXPRESSION --> EQUALITY_EXPRESSION | EQUALITY_EXPRESSION '&' AND_EXPRESSION
 * EQUALITY_EXPRESSION --> RELATIONAL_EXPRESSION | RELATIONAL_EXPRESSION ('==' | '!=') EQUALITY_EXPRESSION
 * RELATIONAL_EXPRESSION --> SHIFT_EXPRESSION | SHIFT_EXPRESSION ('<' | '>' | '<=' | '>=') RELATIONAL_EXPRESSION
 * SHIFT_EXPRESSION --> ADDITIVE_EXPRESSION | ADDITIVE_EXPRESSION ('<<' | '>>') SHIFT_EXPRESSION
 * ADDITIVE_EXPRESSION --> MULTIPLICATIVE_EXPRESSION | MULTIPLICATIVE_EXPRESSION ('+' | '-') ADDITIVE_EXPRESSION
 * MULTIPLICATIVE_EXPRESSION --> CAST_EXPRESSION | CAST_EXPRESSION ('*' | '/' | '%') MULTIPLICATIVE_EXPRESSION
 * 
 * CAST_EXPRESSION --> UNARY_EXPRESSION | '(' TYPE_NAME ')' CAST_EXPRESSION
 * UNARY_EXPRESSION --> POSTFIX_EXPRESSION | ('++' | '--') UNARY_EXPRESSION | ('&' | '*' | '+' | '-' | '~' | '!') CAST_EXPRESSION 
 *     | SIZEOF UNARY_EXPRESSION | SIZEOF '(' TYPE_NAME ')'
 * POSTFIX_EXPRESSION --> PRIMARY_EXPRESSION | POSTFIX_EXPRESSION ('[' EXPRESSION ']' | '(' ARGUMENT_EXPRESSION_LISTopt ')' 
 *     | ('.' | '->') IDENTIFIER | ('++' | '--')) | '(' TYPE_NAME ')' '{' INITIALIZER_LIST '}'
 * ARGUMENT_EXPRESSION_LIST --> ASSIGNMENT_EXPRESSION | ASSIGNMENT_EXPRESSION ',' ARGUMENT_EXPRESSION_LIST
 *     
 * TYPE_NAME --> SPECIFIER_QUALIFIER_LIST POINTERopt
 * SPECIFIER_QUALIFIER_LIST --> (TYPE_SPECIFIER | TYPE_QUALIFIER) SPECIFIER_QUALIFIER_LISTopt
 * 
 * PRIMARY_EXPRESSION --> IDENTIFIER | CONSTANT | STRING_LITERAL | '(' EXPRESSION ')'
 * 
 * TYPE_LIST   --> TYPE TYPE_LIST | TYPE
 * TYPE        --> INT
 * ARGS   	   --> e | ARG_LIST
 * ARG_LIST    --> ARG ',' ARGLIST | ARG
 * ARG    	   --> TYPE ID
 * CODE_BLOCK  --> '{' STMTS '}'
 * STMTS       --> STMT STMTS | e
 * STMT        --> RETURN_STMT
 *
 * RETURN STMT --> RETURN EXPR ';'
 *
 * EXPR        --> TERM EXPR'
 * EXPR'       --> '+' TERM EXPR' | '-' TERM EXPR' | e
 *
 * TERM        --> FACTOR TERM'
 * TERM'       --> '*' FACTOR TERM' | e
 *
 * FACTOR      --> ID  
 * 
 */

class ScannerToken {
	public String lexme;
	public String type;
	public int line;
	public int column;
}

public class LhyParser implements IMiniCCParser {

	private ArrayList<ScannerToken> tknList;
	private int tokenIndex;
	private ScannerToken nextToken;

	@Override
	public String run(String iFile) throws Exception {
		System.out.println("Parsing...");

		String oFile = MiniCCUtil.removeAllExt(iFile) + MiniCCCfg.MINICC_PARSER_OUTPUT_EXT;
		String tFile = MiniCCUtil.removeAllExt(iFile) + MiniCCCfg.MINICC_SCANNER_OUTPUT_EXT;

		tknList = loadTokens(tFile);
		tokenIndex = 0;

		ASTNode root = program();

		String[] dummyStrs = new String[16];
		TreeViewer viewr = new TreeViewer(Arrays.asList(dummyStrs), root);
		viewr.open();

		ObjectMapper mapper = new ObjectMapper();
		mapper.writeValue(new File(oFile), root);

		// TODO: write to file

		return oFile;
	}

	private ArrayList<ScannerToken> loadTokens(String tFile) {
		tknList = new ArrayList<ScannerToken>();

		ArrayList<String> tknStr = MiniCCUtil.readFile(tFile);

		for (String str : tknStr) {
			if (str.trim().length() <= 0) {
				continue;
			}

			ScannerToken st = new ScannerToken();
			// [@0,0:2='int',<'int'>,1:0]
			String[] segs;
			if (str.indexOf("<','>") > 0) {
				str = str.replace("','", "'DOT'");

				segs = str.split(",");
				segs[1] = "=','";
				segs[2] = "<','>";

			} else {
				segs = str.split(",");
			}
			st.lexme = segs[1].substring(segs[1].indexOf("=") + 1);
			st.type = segs[2].substring(segs[2].indexOf("<") + 1, segs[2].length() - 1);
			String[] lc = segs[3].split(":");
			st.line = Integer.parseInt(lc[0]);
			st.column = Integer.parseInt(lc[1].replace("]", ""));

			tknList.add(st);
		}

		return tknList;
	}

	private ScannerToken getToken(int index) {
		if (index < tknList.size()) {
			return tknList.get(index);
		}
		return null;
	}

	public ASTToken matchToken(String type) {
		if (tokenIndex < tknList.size()) {
			ScannerToken next = tknList.get(tokenIndex);
			ASTToken t = new ASTToken();
			if (!next.type.equals(type)) {
				System.out
						.println("[ERROR]Parser: unmatched token, expected = " + type + ", " + "input = " + next.type);
			} else {
				t.tokenId = tokenIndex;
				t.value = next.lexme;
				tokenIndex++;
				return t;
			}
		}
		return null;
	}

	public boolean is_matchToken(String type) {
		if (tokenIndex < tknList.size()) {
			ScannerToken next = tknList.get(tokenIndex);
			if (!next.type.equals(type)) {
				System.out
						.println("[ERROR]Parser: unmatched token, expected = " + type + ", " + "input = " + next.type);
				return false;
			}
		}
		return true;
	}

	public ASTToken try_matchToken(String type) {
		if (tokenIndex < tknList.size()) {
			ScannerToken next = tknList.get(tokenIndex);
			ASTToken t = new ASTToken();
			if (next.type.equals(type)) {
				t.tokenId = tokenIndex;
				t.value = next.lexme;
				tokenIndex++;
				return t;
			}
		}
		return null;
	}

	// PROGRAM --> EXTERNAL_DECLARATION_LIST
	public ASTNode program() {
		ASTCompilationUnit p = new ASTCompilationUnit();

		ASTNode e = external_declaration_list();
		if (e != null) {
			p.items.add(e);
			p.children.add(e);
		}
		return p;
	}

	// EXTERNAL_DECLARATION_LIST --> EXTERNAL_DECLARATION EXTERNAL_DECLARATION_LIST
	// | e
	public ASTMyNode external_declaration_list() {
		ASTMyNode myNode = new ASTMyNode("externalDeclarationList");
		nextToken = tknList.get(tokenIndex);
		while (true) {
			if (nextToken.type.equals("EOF"))
				break;
			ASTNode e = external_declaration();
			if (e != null) {
				myNode.children.add(e);
				myNode.childNodes.add(e);
			} else if (!myNode.children.isEmpty())
				return myNode;
			else
				break;
		}
		return null;
	}

	// EXTERNAL_DECLARATION --> FUNCTION_DEFINITION | DECLARATION
	public ASTMyNode external_declaration() {
		ASTMyNode myNode = new ASTMyNode("externalDeclaration");
		nextToken = tknList.get(tokenIndex);
		if (nextToken.type.equals("EOF")) {
			return null;
		} else {
			ASTNode node;
			if ((node = function_definition()) == null) {
				if ((node = declaration()) == null) {
					return null;
				}
			}
			myNode.children.add(node);
			myNode.childNodes.add(node);
			return myNode;
		}
	}

	// DECLARATION --> DECLARATION_SPECIFIERS INIT_DECLARATOR_LIST ';'
	public ASTDeclaration declaration() {
		ASTDeclaration dec = new ASTDeclaration();
		ASTNode decs = declaration_specifiers();
		if (decs == null)
			return null;

		List<ASTToken> s = new ArrayList<ASTToken>();
		for (ASTNode node : decs.children) {
			ASTNode a = node.children.get(0).children.get(0);
			s.add(myNodetoToken((ASTMyNode) a));
		}
		dec.specifiers = s;
		dec.children.add(decs);

		ASTNode init = init_declarator_list();
		if (init == null)
			return null;

		ArrayList<ASTInitList> initList = new ArrayList<ASTInitList>();
		for (ASTNode node : init.children) {
			if (node.getType().equals("InitList")) {
				initList.add((ASTInitList) node);
			}
		}
		dec.initLists = initList;
		dec.children.add(init);

		ASTToken a = try_matchToken("';'");
		if (a == null)
			return null;
		dec.children.add(tokentoMyNode(a));
		return dec;
	}

	// INIT_DECLARATOR_LIST --> INIT_DECLARATOR ',' INIT_DECLARATOR_LIST |
	// INIT_DECLARATOR
	public ASTMyNode init_declarator_list() {
		ASTMyNode myNode = new ASTMyNode("initDeclaratorList");
		ASTNode a = init_declarator();
		if (a == null)
			return null;
		myNode.children.add(a);
		myNode.childNodes.add(a);

		while (true) {
			ASTToken a1 = try_matchToken("','");
			if (a1 != null) {
				ASTMyNode m1 = new ASTMyNode(a1);
				myNode.children.add(m1);
				myNode.childNodes.add(m1);
				ASTNode a2 = init_declarator();
				if (a2 == null)
					System.out.println("[WARNING]Parser: extra comma");
				else {
					myNode.children.add(a2);
					myNode.childNodes.add(a2);
				}
			} else
				break;
		}
		return myNode;
	}

	// INIT_DECLARATOR --> DECLARATOR '=' INITIALIZER | DECLARATOR
	public ASTInitList init_declarator() {
		ASTInitList init = new ASTInitList();

		ASTVariableDeclarator vd = declarator();
		init.declarator = vd;
		init.children.add(vd);

		ASTToken a = try_matchToken("'='");
		if (a != null) {
			ASTMyNode m1 = new ASTMyNode(a);
			init.children.add(m1);
			ASTExpression ex = assignment_expression();
			List<ASTExpression> exl = new ArrayList<ASTExpression>();
			exl.add(ex);
			init.exprs = exl;
			init.children.add(ex);
		}
		return init;
	}

	// INITIALIZER --> ASSIGNMENT_EXPRESSION

	// ASTToken to ASTMyNode
	public ASTMyNode tokentoMyNode(ASTToken token) {
		ASTMyNode myNode = new ASTMyNode(token.value);
		myNode.setId(token.tokenId);
		return myNode;
	}

	// ASTMyNode to ASTToken
	public ASTToken myNodetoToken(ASTMyNode myNode) {
		ASTToken token = new ASTToken(myNode.specifiedType, myNode.getId());
		return token;
	}

	// FUNCTION_DEFINITION --> DECLARATION_SPECIFIERS DECLARATOR '(' PARAMETER_LIST
	// ')' COMPOUND_STATEMENT
	public ASTFunctionDefine function_definition() {
		ASTFunctionDefine fdef = new ASTFunctionDefine();

		ASTNode decs = declaration_specifiers();
		if (decs == null)
			return null;

		List<ASTToken> s = new ArrayList<ASTToken>();
		for (ASTNode node : decs.children) {
			ASTNode a = node.children.get(0).children.get(0);
			s.add(myNodetoToken((ASTMyNode) a));
		}
		fdef.specifiers = s;
		fdef.children.add(decs);

		ASTFunctionDeclarator fdec = new ASTFunctionDeclarator();

		ASTVariableDeclarator vd = declarator();
		if (vd == null)
			return null;

		fdec.declarator = vd;
		fdec.children.add(vd);

		ASTToken a1 = matchToken("'('");
		fdec.children.add(tokentoMyNode(a1));

		ASTNode p = parameter_list();
		if (p != null) {
			List<ASTParamsDeclarator> pdl = new ArrayList<ASTParamsDeclarator>();
			for (ASTNode pd : p.children) {
				if (pd.getType().equals("ParamsDeclarator"))
					pdl.add((ASTParamsDeclarator) pd);
			}
			fdec.params = pdl;
			fdec.children.add(p);
		}

		ASTToken a2 = matchToken("')'");
		fdec.children.add(tokentoMyNode(a2));

		fdef.declarator = fdec;
		fdef.children.add(fdec);

		ASTCompoundStatement cs = compound_statement();
		if (cs == null)
			return null;

		fdef.body = cs;
		fdef.children.add(cs);

		return fdef;
	}

	// DECLARATION_SPECIFIERS --> DECLARATION_SPECIFIER DECLARATION_SPECIFIERS |
	// DECLARATION_SPECIFIER
	public ASTMyNode declaration_specifiers() {
		ASTMyNode decs = new ASTMyNode("declarationSpecifiers");

		while (true) {
			ASTNode a = declaration_specifier();
			if (a != null) {
				decs.children.add(a);
				decs.childNodes.add(a);
			} else
				break;
		}
		if (decs.children.isEmpty())
			return null;
		return decs;
	}

	// DECLARATION_SPECIFIER --> STORAGE_CLASS_SPECIFIER | TYPE_SPECIFIER |
	// TYPE_QUALIFIER | FUNCTION_SPECIFIER
	public ASTMyNode declaration_specifier() {
		ASTMyNode dec = new ASTMyNode("declarationSpecifier");
		ASTNode t;
		if ((t = storage_class_specifier()) == null) {
			if ((t = type_specifier()) == null) {
				if ((t = type_qualifier()) == null) {
					if ((t = function_specifier()) == null) {
						return null;
					}
				}
			}
		}
		dec.children.add(t);
		dec.childNodes.add(t);
		return dec;
	}

	// STORAGE_CLASS_SPECIFIER --> TYPEDEF | EXTERN | STATIC | AUTO
	public ASTMyNode storage_class_specifier() {
		ASTMyNode myNode = new ASTMyNode("storageClassSpecifier");
		ScannerToken st = tknList.get(tokenIndex);

		if (st.type.equals("'typedef'") | st.type.equals("'extern'") | st.type.equals("'static'")
				| st.type.equals("'auto'")) {
			ASTMyNode myLeaf = new ASTMyNode(st.type);
			myLeaf.setId(tokenIndex);
			tokenIndex++;
			myNode.children.add(myLeaf);
			myNode.childNodes.add(myLeaf);
			return myNode;
		}
		return null;
	}

	// TYPE_SPECIFIER --> VOID | CHAR | SHORT | INT | LONG | FLOAT | DOUBLE | SIGNED
	// | UNSIGNED
	public ASTMyNode type_specifier() {
		ASTMyNode myNode = new ASTMyNode("typeSpecifier");
		ScannerToken st = tknList.get(tokenIndex);

		if (st.type.equals("'void'") | st.type.equals("'char'") | st.type.equals("'short'") | st.type.equals("'int'")
				| st.type.equals("'long'") | st.type.equals("'float'") | st.type.equals("'double'")
				| st.type.equals("'signed'") | st.type.equals("'unsigned'")) {
			ASTMyNode myLeaf = new ASTMyNode(st.type);
			myLeaf.setId(tokenIndex);
			tokenIndex++;
			myNode.children.add(myLeaf);
			myNode.childNodes.add(myLeaf);
			return myNode;
		}
		return null;
	}

	// TYPE_QUALIFIER --> CONST | RESTRICT | VOLATILE
	public ASTMyNode type_qualifier() {
		ASTMyNode myNode = new ASTMyNode("typeQualifier");
		ScannerToken st = tknList.get(tokenIndex);

		if (st.type.equals("'const'") | st.type.equals("'restrict'") | st.type.equals("'volatile'")) {
			ASTMyNode myLeaf = new ASTMyNode(st.type);
			myLeaf.setId(tokenIndex);
			tokenIndex++;
			myNode.children.add(myLeaf);
			myNode.childNodes.add(myLeaf);
			return myNode;
		}
		return null;
	}

	// FUNCTION_SPECIFIER --> INLINE
	public ASTMyNode function_specifier() {
		ASTMyNode myNode = new ASTMyNode("functionSpecifier");
		ScannerToken st = tknList.get(tokenIndex);

		if (st.type.equals("'inline'")) {
			ASTMyNode myLeaf = new ASTMyNode(st.type);
			myLeaf.setId(tokenIndex);
			tokenIndex++;
			myNode.children.add(myLeaf);
			myNode.childNodes.add(myLeaf);
			return myNode;
		}
		return null;
	}

	// DECLARATOR --> POINTER IDENTIFIER | IDENTIFIER
	public ASTVariableDeclarator declarator() {
		ASTVariableDeclarator vd = new ASTVariableDeclarator();

		ASTNode p = pointer();
		if (p != null)
			vd.children.add(p);

		ASTIdentifier id = new ASTIdentifier();

		ASTToken a = matchToken("Identifier");
		id.tokenId = a.tokenId;
		id.value = a.value;
		id.children.add(tokentoMyNode(a));

		vd.identifier = id;
		vd.children.add(id);
		return vd;
	}

	// POINTER --> '*' POINTER | '*'
	public ASTMyNode pointer() {
		ASTMyNode myNode = new ASTMyNode("pointer");
		while (true) {
			ASTToken a = try_matchToken("'*'");
			if (a != null) {
				ASTMyNode m1 = new ASTMyNode(a);
				myNode.children.add(m1);
				myNode.childNodes.add(m1);
			} else
				break;
		}
		if (myNode.children.isEmpty())
			return null;
		return myNode;
	}

	// PARAMETER_LIST --> PARAMETER_DECLARATION ',' PARAMETER_LIST |
	// PARAMETER_DECLARATION | e
	public ASTMyNode parameter_list() {
		ASTMyNode myNode = new ASTMyNode("parameterList");
		nextToken = tknList.get(tokenIndex);
		if (nextToken.type.equals("')'")) { // ending
			return null;
		} else {
			ASTNode a = parameter_declaration();
			if (a == null)
				return null;
			myNode.children.add(a);
			myNode.childNodes.add(a);
			while (true) {
				ASTToken token = try_matchToken("','");
				if (token != null) {
					ASTMyNode m1 = new ASTMyNode(token);
					myNode.children.add(m1);
					myNode.childNodes.add(m1);
					ASTNode a1 = parameter_declaration();
					if (a1 != null) {
						myNode.children.add(a1);
						myNode.childNodes.add(a1);
					}
				} else
					break;
			}
			return myNode;
		}
	}

	// PARAMETER_DECLARATION --> DECLARATION_SPECIFIERS DECLARATOR
	public ASTParamsDeclarator parameter_declaration() {
		ASTParamsDeclarator pd = new ASTParamsDeclarator();

		ASTNode ds = declaration_specifiers();
		if (ds == null)
			return null;
		List<ASTToken> s = new ArrayList<ASTToken>();
		for (ASTNode node : ds.children) {
			ASTNode a = node.children.get(0).children.get(0);
			s.add(myNodetoToken((ASTMyNode) a));
		}
		pd.specfiers = s;
		pd.children.add(ds);

		ASTVariableDeclarator vd = declarator();
		if (vd == null)
			return null;

		pd.declarator = vd;
		pd.children.add(vd);

		return pd;
	}

	// COMPOUND_STATEMENT --> '{' BLOCK_ITEM_LISTopt '}'
	public ASTCompoundStatement compound_statement() {
		ASTCompoundStatement compoundStatement = new ASTCompoundStatement();
		ASTToken a1 = try_matchToken("'{'");
		if (a1 == null)
			return null;
		compoundStatement.children.add(tokentoMyNode(a1));

		ASTNode bil = block_item_list();
		if (bil != null) {
			compoundStatement.children.add(bil);
			compoundStatement.blockItems.addAll(bil.children);
		}

		ASTToken a2 = matchToken("'}'");
		compoundStatement.children.add(tokentoMyNode(a2));
		return compoundStatement;
	}

	// BLOCK_ITEM_LIST --> BLOCK_ITEM | BLOCK_ITEM BLOCK_ITEM_LIST
	public ASTMyNode block_item_list() {
		ASTMyNode myNode = new ASTMyNode("blockItemList");
		while (true) {
			ASTNode node = block_item();
			if (node != null) {
				myNode.children.add(node);
				myNode.childNodes.add(node);
			} else
				break;
		}
		if (myNode.children.isEmpty())
			return null;
		return myNode;
	}

	// BLOCK_ITEM --> DECLARATION | STATEMENT
	public ASTMyNode block_item() {
		ASTMyNode myNode = new ASTMyNode("blockItem");
		ASTNode node;
		if ((node = declaration()) == null) {
			if ((node = statement()) == null) {
				return null;
			}
		}
		myNode.children.add(node);
		myNode.childNodes.add(node);
		return myNode;
	}

	// STATEMENT --> LABELED_STATEMENT | COMPOUND_STATEMENT | EXPRESSION_STATEMENT |
	// SELECTION_STATEMENT | ITERATION_STATEMENT | JUMP_STATEMENT
	public ASTMyNode statement() {
		ASTMyNode myNode = new ASTMyNode("statement");

		ASTNode node;
		if ((node = labeled_statement()) == null) {
			if ((node = compound_statement()) == null) {
				if ((node = expression_statement()) == null) {
					if ((node = selection_statement()) == null) {
						if ((node = iteration_statement()) == null) {
							if ((node = jump_statement()) == null) {
								return null;
							}
						}
					}
				}
			}
		}
		myNode.children.add(node);
		myNode.childNodes.add(node);
		return myNode;
	}

	// LABELED_STATEMENT --> IDENTIFIER ':' STATEMENT | CASE CONDITIONAL_EXPRESSION
	// ':' STATEMENT | DEFAULT ':' STATEMENT
	public ASTLabeledStatement labeled_statement() {
		ASTLabeledStatement labeledStatement = new ASTLabeledStatement();
		ASTIdentifier id = new ASTIdentifier();
		ASTToken token;
		if ((token = try_matchToken("Identifier")) == null) {
			if ((token = try_matchToken("'case'")) == null) {
				if ((token = try_matchToken("'default'")) == null) {
					return null;
				} else {
					labeledStatement.children.add(tokentoMyNode(token));
				}
			} else {
				labeledStatement.children.add(tokentoMyNode(token));
				ASTConditionExpression conditionExpression = conditional_expression();
				labeledStatement.children.add(conditionExpression);
			}
		} else {
			id.children.add(tokentoMyNode(token));
			id.tokenId = token.tokenId;
			id.value = token.value;
			labeledStatement.children.add(id);
		}
		labeledStatement.label = id;
		ASTToken a = try_matchToken("':'");
		if (a == null) {
			tokenIndex--;
			return null;
		}
		labeledStatement.children.add(tokentoMyNode(a));

		ASTNode statement = statement();
		labeledStatement.children.add(statement);
		labeledStatement.stat = (ASTStatement) statement.children.get(0);

		return labeledStatement;
	}

	// EXPRESSION_STATEMENT --> EXPRESSIONopt ';'
	public ASTExpressionStatement expression_statement() {
		ASTExpressionStatement expressionStatement = new ASTExpressionStatement();
		ASTMyExpression expression = expression();
		if (expression == null)
			return null;
		expressionStatement.exprs.addAll(expression.exprs);
		expressionStatement.children.add(expression);

		ASTToken a = matchToken("';'");
		expressionStatement.children.add(tokentoMyNode(a));

		return expressionStatement;
	}

	// SELECTION-STATEMENT --> IF '(' EXPRESSION ')' STATEMENT | IF '(' EXPRESSION
	// ')' STATEMENT ELSE STATEMENT | SWITCH '(' EXPRESSION ')' STATEMENT
	public ASTSelectionStatement selection_statement() {
		ASTSelectionStatement selectionStatement = new ASTSelectionStatement();
		ASTToken a1;
		if ((a1 = try_matchToken("'if'")) == null) {
			if ((a1 = try_matchToken("'switch'")) == null) {
				return null;
			}
		}
		selectionStatement.children.add(tokentoMyNode(a1));

		ASTToken a2 = matchToken("'('");
		selectionStatement.children.add(tokentoMyNode(a2));
		ASTMyExpression expression = expression();
		if (expression == null)
			return null;
		selectionStatement.cond.addAll(expression.exprs);
		selectionStatement.children.add(expression);
		ASTToken a3 = matchToken("')'");
		selectionStatement.children.add(tokentoMyNode(a3));

		ASTNode statement = statement();
		selectionStatement.children.add(statement);
		selectionStatement.then = (ASTStatement) (statement.children.get(0));

		if (a1.value.equals("'if'")) {
			ASTToken a4 = try_matchToken("'else'");
			if (a4 == null)
				return selectionStatement;
			selectionStatement.children.add(tokentoMyNode(a4));
			ASTNode statement2 = statement();
			selectionStatement.children.add(statement2);
			selectionStatement.otherwise = (ASTStatement) statement2.children.get(0);
		}
		return selectionStatement;
	}

	// ITERATION-STATEMENT --> WHILE '(' EXPRESSION ')' STATEMENT | DO STATEMENT
	// WHILE '(' EXPRESSION ')' ';' | FOR '(' EXPRESSIONopt ';' EXPRESSIONopt ';'
	// EXPRESSIONopt ')' STATEMENT | FOR '(' DECLARATION EXPRESSIONopt ';'
	// EXPRESSIONopt ')' STATEMENT
	public ASTIterationStatement iteration_statement() {
		ASTIterationStatement iterationStatement = new ASTIterationStatement();

		ASTToken a1;
		if ((a1 = try_matchToken("'while'")) == null) {
			if ((a1 = try_matchToken("'do'")) == null) {
				if ((a1 = try_matchToken("'for'")) == null) {
					return null;
				} else {
					iterationStatement.children.add(tokentoMyNode(a1));
					ASTToken a2 = matchToken("'('");
					iterationStatement.children.add(tokentoMyNode(a2));

					ASTDeclaration declaration = declaration();
					if (declaration != null) {
						iterationStatement.children.add(declaration);
					} else {
						ASTMyExpression expression = expression();
						if (expression != null)
							iterationStatement.init.add(expression);
						a2 = matchToken("';'");
						iterationStatement.children.add(tokentoMyNode(a2));
					}

					ASTMyExpression expression = expression();
					if (expression != null)
						iterationStatement.cond.add(expression);
					a2 = matchToken("';'");
					iterationStatement.children.add(tokentoMyNode(a2));
					expression = expression();
					if (expression != null)
						iterationStatement.step.add(expression);

					a2 = matchToken("')'");
					iterationStatement.children.add(tokentoMyNode(a2));

					ASTMyNode statement = statement();
					if (statement != null) {
						iterationStatement.children.add(statement);
						iterationStatement.stat = (ASTStatement) statement.children.get(0);
					}
				}
			} else {
				iterationStatement.children.add(tokentoMyNode(a1));
				ASTMyNode statement = statement();
				if (statement != null) {
					iterationStatement.children.add(statement);
					iterationStatement.stat = (ASTStatement) statement.children.get(0);
				}

				ASTToken a2 = matchToken("'('");
				iterationStatement.children.add(tokentoMyNode(a2));
				ASTMyExpression expression = expression();
				if (expression == null)
					return null;
				iterationStatement.cond = new LinkedList<ASTExpression>();
				iterationStatement.cond.add(expression);
				a2 = matchToken("')'");
				iterationStatement.children.add(tokentoMyNode(a2));
				a2 = matchToken("';'");
				iterationStatement.children.add(tokentoMyNode(a2));

			}
		} else {
			iterationStatement.children.add(tokentoMyNode(a1));
			ASTToken a2 = matchToken("'('");
			iterationStatement.children.add(tokentoMyNode(a2));
			ASTMyExpression expression = expression();
			if (expression == null)
				return null;
			iterationStatement.cond.add(expression);
			a2 = matchToken("')'");
			iterationStatement.children.add(tokentoMyNode(a2));

			ASTMyNode statement = statement();
			if (statement != null) {
				iterationStatement.children.add(statement);
				iterationStatement.stat = (ASTStatement) statement.children.get(0);
			}
		}
		return iterationStatement;
	}

	// JUMP-STATEMENT --> GOTO IDENTIFIER ';' | CONTINUE ';' | BREAK ';' | RETURN
	// EXPRESSIONopt ';'
	public ASTJumpStatement jump_statement() {
		ASTJumpStatement jumpStatement = new ASTJumpStatement();

		ASTToken a1;
		if ((a1 = try_matchToken("'goto'")) == null) {
			if ((a1 = try_matchToken("'continue'")) == null) {
				if ((a1 = try_matchToken("'break'")) == null) {
					if ((a1 = try_matchToken("'return'")) == null) {
						return null;
					} else {
						ASTReturnStatement returnStatement = new ASTReturnStatement();
						returnStatement.children.add(tokentoMyNode(a1));
						ASTMyExpression expression = expression();
						if (expression != null)
							returnStatement.expr.addAll(expression.exprs);
						returnStatement.children.add(expression);
						ASTToken token = matchToken("';'");
						returnStatement.children.add(tokentoMyNode(token));

						jumpStatement.children.add(returnStatement);
						jumpStatement.stat = returnStatement;
						jumpStatement.token = a1;
					}
				} else {
					ASTBreakStatement breakStatement = new ASTBreakStatement();
					breakStatement.children.add(tokentoMyNode(a1));

					jumpStatement.children.add(breakStatement);
					jumpStatement.stat = breakStatement;
					jumpStatement.token = a1;
				}
			} else {
				ASTContinueStatement continueStatement = new ASTContinueStatement();
				continueStatement.children.add(tokentoMyNode(a1));

				jumpStatement.children.add(continueStatement);
				jumpStatement.stat = continueStatement;
				jumpStatement.token = a1;
			}
		} else {
			ASTGotoStatement gotoStatement = new ASTGotoStatement();
			ASTIdentifier identifier = new ASTIdentifier();
			ASTToken token = matchToken("Identifier");
			identifier.tokenId = token.tokenId;
			identifier.value = token.value;

			identifier.children.add(tokentoMyNode(token));
			gotoStatement.label = identifier;
			gotoStatement.children.add(identifier);

			jumpStatement.children.add(gotoStatement);
			jumpStatement.stat = gotoStatement;
			jumpStatement.token = a1;
		}
		return jumpStatement;
	}

	// EXPRESSION --> ASSIGNMENT-EXPRESSION | ASSIGNMENT-EXPRESSION ',' EXPRESSION
	public ASTMyExpression expression() {
		ASTMyExpression expression = new ASTMyExpression("expression");

		ASTMyExpression assignmentExpression = assignment_expression();
		if (assignmentExpression == null)
			return null;
		expression.children.add(assignmentExpression);
		expression.exprs.add(assignmentExpression);
		while (true) {
			ASTToken token = try_matchToken("','");
			if (token != null) {
				ASTMyExpression assignmentExpression2 = assignment_expression();
				if (assignmentExpression2 != null) {
					expression.children.add(tokentoMyNode(token));
					expression.ops.add(token);
					expression.children.add(assignmentExpression2);
					expression.exprs.add(assignmentExpression2);
				} else
					break;
			} else
				break;
		}
		return expression;

	}

	// ASSIGNMENT_EXPRESSION --> CONDITIONAL_EXPRESSION | UNARY_EXPRESSION
	// ASSIGNMENT_OPERATOR ASSIGNMENT_EXPRESSION
	public ASTMyExpression assignment_expression() {
		ASTMyExpression assignmentExpression = new ASTMyExpression("assignmentExpression");
		int index = tokenIndex;
		ASTConditionExpression conditionExpression = conditional_expression();
		if (conditionExpression != null) {
			if (is_assignment_operator(tknList.get(tokenIndex).type)) {
				tokenIndex = index;
			} else {
				assignmentExpression.children.add(conditionExpression);
				assignmentExpression.exprs.add(conditionExpression);
				return assignmentExpression;
			}
		}
		ASTUnaryExpression unaryExpression = unary_expression();
		if (unaryExpression == null)
			return null;
		assignmentExpression.children.add(unaryExpression);
		assignmentExpression.exprs.add(unaryExpression);

		ScannerToken st = tknList.get(tokenIndex);
		if (is_assignment_operator(st.type)) {
			ASTMyNode myLeaf = new ASTMyNode(st.type);
			myLeaf.setId(tokenIndex);
			tokenIndex++;
			assignmentExpression.ops.add(myLeaf.toToken());
			assignmentExpression.children.add(myLeaf);
		} else
			return assignmentExpression;
		ASTMyExpression assignmentExpression2 = assignment_expression();
		if (assignmentExpression2 == null)
			return null;
		assignmentExpression.exprs.add(assignmentExpression2);
		assignmentExpression.children.add(assignmentExpression2);
		return assignmentExpression;
	}

	// ASSIGNMENT_OPERATOR --> '=' | '*=' | '/=' | '%=' | '+=' | '-=' | '<<=' |
	// '>>=' | '&=' | '^=' | '|='
	boolean is_assignment_operator(String s) {
		if (s.equals("'='") | s.equals("'*='") | s.equals("'/='") | s.equals("'%='") | s.equals("'+='")
				| s.equals("'-='") | s.equals("'<<='") | s.equals("'>>='") | s.equals("'&='") | s.equals("'^='")
				| s.equals("'|='")) {
			return true;
		}
		return false;
	}

	// CONDITIONAL_EXPRESSION --> LOGICAL_OR_EXPRESSION | LOGICAL_OR_EXPRESSION ?
	// EXPRESSION : CONDITIONAL_EXPRESSION
	public ASTConditionExpression conditional_expression() {
		ASTConditionExpression conditionExpression = new ASTConditionExpression();
		ASTMyExpression logicalOrExpression = logical_or_expression();
		if (logicalOrExpression == null)
			return null;
		conditionExpression.condExpr = logicalOrExpression;
		conditionExpression.children.add(logicalOrExpression);
		ASTToken token = try_matchToken("'?'");
		if (token != null) {
			conditionExpression.children.add(tokentoMyNode(token));
			ASTMyExpression expression = expression();
			if (expression == null)
				return null;
			conditionExpression.trueExpr.addAll(expression.exprs);
			conditionExpression.children.add(expression);
			ASTToken token2 = matchToken("':'");
			conditionExpression.children.add(tokentoMyNode(token2));
			ASTConditionExpression conditionExpression2 = conditional_expression();
			conditionExpression.falseExpr = conditionExpression2;
			conditionExpression.children.add(conditionExpression2);
		}
		return conditionExpression;
	}

	// LOGICAL_OR_EXPRESSION --> LOGICAL_AND_EXPRESSION | LOGICAL_AND_EXPRESSION
	// '||' LOGICAL_OR_EXPRESSION
	public ASTMyExpression logical_or_expression() {
		ASTMyExpression logicalOrExpression = new ASTMyExpression("logicalOrExpression");
		ASTMyExpression logicalAndExpression = logical_and_expression();
		if (logicalAndExpression == null)
			return null;
		logicalOrExpression.exprs.add(logicalAndExpression);
		logicalOrExpression.children.add(logicalAndExpression);
		ASTToken token = try_matchToken("'||'");
		if (token != null) {
			logicalOrExpression.children.add(tokentoMyNode(token));
			logicalOrExpression.ops.add(token);
			ASTMyExpression logicalOrExpression2 = logical_or_expression();
			if (logicalOrExpression2 == null)
				return null;
			logicalOrExpression.exprs.add(logicalOrExpression2);
			logicalOrExpression.children.add(logicalOrExpression2);
		}
		return logicalOrExpression;
	}

	// LOGICAL_AND_EXPRESSION --> INCLUSIVE_OR_EXPRESSION | INCLUSIVE_OR_EXPRESSION
	// '&&' LOGICAL_AND_EXPRESSION
	public ASTMyExpression logical_and_expression() {
		ASTMyExpression logicalAndExpression = new ASTMyExpression("logicalAndExpression");
		ASTMyExpression inclusiveOrExpression = inclusive_or_expression();
		if (inclusiveOrExpression == null)
			return null;
		logicalAndExpression.exprs.add(inclusiveOrExpression);
		logicalAndExpression.children.add(inclusiveOrExpression);
		ASTToken token = try_matchToken("'&&'");
		if (token != null) {
			logicalAndExpression.children.add(tokentoMyNode(token));
			logicalAndExpression.ops.add(token);
			ASTMyExpression logicalAndExpression2 = logical_and_expression();
			if (logicalAndExpression2 == null)
				return null;
			logicalAndExpression.exprs.add(logicalAndExpression2);
			logicalAndExpression.children.add(logicalAndExpression2);
		}
		return logicalAndExpression;
	}

	// EXCLUSIVE_OR_EXPRESSION --> AND_EXPRESSION | AND_EXPRESSION '^'
	// EXCLUSIVE_OR_EXPRESSION
	public ASTMyExpression inclusive_or_expression() {
		ASTMyExpression inclusiveOrExpression = new ASTMyExpression("inclusiveOrExpression");
		ASTMyExpression andExpression = and_expression();
		if (andExpression == null)
			return null;
		inclusiveOrExpression.exprs.add(andExpression);
		inclusiveOrExpression.children.add(andExpression);
		ASTToken token = try_matchToken("'^'");
		if (token != null) {
			inclusiveOrExpression.children.add(tokentoMyNode(token));
			inclusiveOrExpression.ops.add(token);
			ASTMyExpression inclusiveOrExpression2 = inclusive_or_expression();
			if (inclusiveOrExpression2 == null)
				return null;
			inclusiveOrExpression.exprs.add(inclusiveOrExpression2);
			inclusiveOrExpression.children.add(inclusiveOrExpression2);
		}
		return inclusiveOrExpression;
	}

	// AND_EXPRESSION --> EQUALITY_EXPRESSION | EQUALITY_EXPRESSION '&'
	// AND_EXPRESSION
	public ASTMyExpression and_expression() {
		ASTMyExpression andExpression = new ASTMyExpression("andExpression");
		ASTMyExpression equalityExpression = equality_expression();
		if (equalityExpression == null)
			return null;
		andExpression.exprs.add(equalityExpression);
		andExpression.children.add(equalityExpression);
		ASTToken token = try_matchToken("'&'");
		if (token != null) {
			andExpression.children.add(tokentoMyNode(token));
			andExpression.ops.add(token);
			ASTMyExpression andExpression2 = and_expression();
			if (andExpression2 == null)
				return null;
			andExpression.exprs.add(andExpression2);
			andExpression.children.add(andExpression2);
		}
		return andExpression;
	}

	// EQUALITY_EXPRESSION --> RELATIONAL_EXPRESSION | RELATIONAL_EXPRESSION ('==' |
	// '!=') EQUALITY_EXPRESSION
	public ASTMyExpression equality_expression() {
		ASTMyExpression equalityExpression = new ASTMyExpression("equalityExpression");
		ASTMyExpression relationalExpression = relational_expression();
		if (relationalExpression == null)
			return null;
		equalityExpression.exprs.add(relationalExpression);
		equalityExpression.children.add(relationalExpression);
		ASTToken token = try_matchToken("'=='");
		if (token == null)
			token = try_matchToken("'!='");
		if (token != null) {
			equalityExpression.children.add(tokentoMyNode(token));
			equalityExpression.ops.add(token);
			ASTMyExpression equalityExpression2 = equality_expression();
			if (equalityExpression2 == null)
				return null;
			equalityExpression.exprs.add(equalityExpression2);
			equalityExpression.children.add(equalityExpression2);
		}
		return equalityExpression;
	}

	// RELATIONAL_EXPRESSION --> SHIFT_EXPRESSION | SHIFT_EXPRESSION ('<' | '>' |
	// '<=' | '>=') RELATIONAL_EXPRESSION
	public ASTMyExpression relational_expression() {
		ASTMyExpression relationalExpression = new ASTMyExpression("relationalExpression");
		ASTMyExpression shiftExpression = shift_expression();
		if (shiftExpression == null)
			return null;
		relationalExpression.exprs.add(shiftExpression);
		relationalExpression.children.add(shiftExpression);
		ASTToken token = try_matchToken("'<'");
		if (token == null)
			token = try_matchToken("'>'");
		if (token == null)
			token = try_matchToken("'<='");
		if (token == null)
			token = try_matchToken("'>='");
		if (token != null) {
			relationalExpression.children.add(tokentoMyNode(token));
			relationalExpression.ops.add(token);
			ASTMyExpression relationalExpression2 = relational_expression();
			if (relationalExpression2 == null)
				return null;
			relationalExpression.exprs.add(relationalExpression2);
			relationalExpression.children.add(relationalExpression2);
		}
		return relationalExpression;
	}

	// SHIFT_EXPRESSION --> ADDITIVE_EXPRESSION | ADDITIVE_EXPRESSION ('<<' | '>>')
	// SHIFT_EXPRESSION
	public ASTMyExpression shift_expression() {
		ASTMyExpression shiftExpression = new ASTMyExpression("shiftExpression");
		ASTMyExpression additiveExpression = additive_expression();
		if (additiveExpression == null)
			return null;
		shiftExpression.exprs.add(additiveExpression);
		shiftExpression.children.add(additiveExpression);
		ASTToken token = try_matchToken("'<<'");
		if (token == null)
			token = try_matchToken("'>>'");
		if (token != null) {
			shiftExpression.children.add(tokentoMyNode(token));
			shiftExpression.ops.add(token);
			ASTMyExpression shiftExpression2 = shift_expression();
			if (shiftExpression2 == null)
				return null;
			shiftExpression.exprs.add(shiftExpression2);
			shiftExpression.children.add(shiftExpression2);
		}
		return shiftExpression;
	}

	// ADDITIVE_EXPRESSION --> MULTIPLICATIVE_EXPRESSION | MULTIPLICATIVE_EXPRESSION
	// ('+' | '-') ADDITIVE_EXPRESSION
	public ASTMyExpression additive_expression() {
		ASTMyExpression additiveExpression = new ASTMyExpression("additiveExpression");
		ASTMyExpression multiplicativeExpression = multiplicative_expression();
		if (multiplicativeExpression == null)
			return null;
		additiveExpression.exprs.add(multiplicativeExpression);
		additiveExpression.children.add(multiplicativeExpression);
		ASTToken token = try_matchToken("'+'");
		if (token == null)
			token = try_matchToken("'-'");
		if (token != null) {
			additiveExpression.children.add(tokentoMyNode(token));
			additiveExpression.ops.add(token);
			ASTMyExpression additiveExpression2 = additive_expression();
			if (additiveExpression2 == null)
				return null;
			additiveExpression.exprs.add(additiveExpression2);
			additiveExpression.children.add(additiveExpression2);
		}
		return additiveExpression;
	}

	// MULTIPLICATIVE_EXPRESSION --> CAST_EXPRESSION | CAST_EXPRESSION ('*' | '/' |
	// '%') MULTIPLICATIVE_EXPRESSION
	public ASTMyExpression multiplicative_expression() {
		ASTMyExpression multiplicativeExpression = new ASTMyExpression("multiplicativeExpression");
		ASTCastExpression castExpression = cast_expression();
		if (castExpression == null)
			return null;
		multiplicativeExpression.exprs.add(castExpression);
		multiplicativeExpression.children.add(castExpression);
		ASTToken token = try_matchToken("'*'");
		if (token == null)
			token = try_matchToken("'/'");
		if (token == null)
			token = try_matchToken("'%'");
		if (token != null) {
			multiplicativeExpression.children.add(tokentoMyNode(token));
			multiplicativeExpression.ops.add(token);
			ASTMyExpression multiplicativeExpression2 = multiplicative_expression();
			if (multiplicativeExpression2 == null)
				return null;
			multiplicativeExpression.exprs.add(multiplicativeExpression2);
			multiplicativeExpression.children.add(multiplicativeExpression2);
		}
		return multiplicativeExpression;
	}

	// CAST_EXPRESSION --> UNARY_EXPRESSION | '(' TYPE_NAME ')' CAST_EXPRESSION
	public ASTCastExpression cast_expression() {
		ASTCastExpression castExpression = new ASTCastExpression();
		ASTToken token = try_matchToken("'('");
		if (token != null) {
			castExpression.children.add(tokentoMyNode(token));
			ASTTypename typename = type_name();
			castExpression.typename = typename;
			castExpression.children.add(typename);
			ASTToken token2 = matchToken("')'");
			castExpression.children.add(tokentoMyNode(token2));
			ASTCastExpression castExpression2 = cast_expression();
			if (castExpression2 == null)
				return null;
			castExpression.expr = castExpression2;
			castExpression.children.add(castExpression2);
			return castExpression;
		}
		ASTUnaryExpression unaryExpression = unary_expression();
		if (unaryExpression == null)
			return null;
		castExpression.expr = unaryExpression;
		castExpression.children.add(unaryExpression);
		return castExpression;
	}

	// TYPE_NAME --> SPECIFIER_QUALIFIER_LIST POINTERopt
	// SPECIFIER_QUALIFIER_LIST --> (TYPE_SPECIFIER | TYPE_QUALIFIER)
	// SPECIFIER_QUALIFIER_LISTopt
	public ASTTypename type_name() {
		ASTTypename typename = new ASTTypename();
		while (true) {
			ASTNode node = type_specifier();
			if (node == null)
				node = type_qualifier();
			if (node == null)
				break;
			typename.specfiers.add(myNodetoToken((ASTMyNode) node.children.get(0)));
			typename.children.add(node);
		}
		if (typename.specfiers.isEmpty())
			return null;
		ASTNode pointer = pointer();
		if (pointer != null)
			typename.children.add(pointer);
		return typename;
	}

	// UNARY_EXPRESSION --> POSTFIX_EXPRESSION | ('++' | '--') UNARY_EXPRESSION |
	// ('&' | '*' | '+' | '-' | '~' | '!') CAST_EXPRESSION | SIZEOF UNARY_EXPRESSION
	// | SIZEOF '(' TYPE_NAME ')'
	public ASTUnaryExpression unary_expression() {
		ASTUnaryExpression unaryExpression = new ASTUnaryExpression();
		ASTPostfixExpression postfixExpression = postfix_expression();
		if (postfixExpression == null) {
			ScannerToken st = tknList.get(tokenIndex);
			if (st.type.equals("'++'") | st.type.equals("'--'")) {
				ASTToken token = new ASTToken(st.lexme, tokenIndex);
				tokenIndex++;
				unaryExpression.op = token;
				unaryExpression.children.add(tokentoMyNode(token));
				ASTUnaryExpression unaryExpression2 = unary_expression();
				if (unaryExpression2 == null)
					return null;
				unaryExpression.expr = unaryExpression2;
				unaryExpression.children.add(unaryExpression2);
				return unaryExpression;
			} else if (st.type.equals("'&'") | st.type.equals("'*'") | st.type.equals("'+'") | st.type.equals("'-'")
					| st.type.equals("'~'") | st.type.equals("'!'")) {
				ASTToken token = new ASTToken(st.lexme, tokenIndex);
				tokenIndex++;
				unaryExpression.op = token;
				unaryExpression.children.add(tokentoMyNode(token));
				ASTCastExpression castExpression = cast_expression();
				if (castExpression == null)
					return null;
				unaryExpression.expr = castExpression;
				unaryExpression.children.add(castExpression);
				return unaryExpression;
			} else if (st.type.equals("'sizeof'")) {
				ASTToken token = new ASTToken(st.lexme, tokenIndex);
				tokenIndex++;
				unaryExpression.op = token;
				unaryExpression.children.add(tokentoMyNode(token));
				ASTToken token2 = try_matchToken("'('");
				if (token2 == null) {
					ASTUnaryExpression unaryExpression2 = unary_expression();
					if (unaryExpression2 == null)
						return null;
					unaryExpression.expr = unaryExpression2;
					unaryExpression.children.add(unaryExpression2);
				} else {
					unaryExpression.children.add(tokentoMyNode(token2));
					ASTTypename typename = type_name();
					if (typename == null)
						return null;
					unaryExpression.children.add(typename);
					ASTToken token3 = matchToken("')'");
					unaryExpression.children.add(tokentoMyNode(token3));
				}
				return unaryExpression;
			} else
				return null;
		}
		unaryExpression.expr = postfixExpression;
		unaryExpression.children.add(postfixExpression);
		return unaryExpression;
	}

	// POSTFIX_EXPRESSION --> PRIMARY_EXPRESSION | POSTFIX_EXPRESSION ('['
	// EXPRESSION ']' | '(' ARGUMENT_EXPRESSION_LISTopt ')' | ('.' | '->')
	// IDENTIFIER | ('++' | '--')) | '(' TYPE_NAME ')' '{' INITIALIZER_LIST '}'
	public ASTPostfixExpression postfix_expression() {
		ASTPostfixExpression postfixExpression = new ASTPostfixExpression();
		ASTMyExpression myExpression = primary_expression();
		if (myExpression == null)
			return null;
		postfixExpression.expr = myExpression;
		postfixExpression.children.add(myExpression);

		while (true) {
			ScannerToken st = tknList.get(tokenIndex);
			if (st.type.equals("'['")) {
				ASTMyNode myNode = new ASTMyNode(st.lexme);
				myNode.setId(tokenIndex);
				tokenIndex++;

				postfixExpression.op = myNode.toToken();
				postfixExpression.children.add(myNode);
				ASTExpression expression = expression();
				if (expression != null)
					postfixExpression.children.add(expression);
				ASTToken token = matchToken("']'");
				postfixExpression.children.add(tokentoMyNode(token));
			} else if (st.type.equals("'('")) {
				ASTMyNode myNode = new ASTMyNode(st.lexme);
				myNode.setId(tokenIndex);
				tokenIndex++;

				postfixExpression.op = myNode.toToken();
				postfixExpression.children.add(myNode);
				ASTExpression expression = argument_expression_list();
				if (expression != null)
					postfixExpression.children.add(expression);
				ASTToken token = matchToken("')'");
				postfixExpression.children.add(tokentoMyNode(token));
			} else if (st.type.equals("'.'") | st.type.equals("'->'")) {
				ASTMyNode myNode = new ASTMyNode(st.lexme);
				myNode.setId(tokenIndex);
				tokenIndex++;
				postfixExpression.op = myNode.toToken();
				postfixExpression.children.add(myNode);

				ASTIdentifier identifier = new ASTIdentifier();
				myNode = new ASTMyNode(st.lexme);
				myNode.setId(tokenIndex);
				identifier.value = st.lexme;
				identifier.tokenId = tokenIndex;
				tokenIndex++;

				identifier.children.add(myNode);
				postfixExpression.children.add(identifier);
			} else if (st.type.equals("'++'") | st.type.equals("'--'")) {
				ASTMyNode myNode = new ASTMyNode(st.lexme);
				myNode.setId(tokenIndex);
				tokenIndex++;
				postfixExpression.op = myNode.toToken();
				postfixExpression.children.add(myNode);
			} else
				break;
		}
		return postfixExpression;
	}

	// ARGUMENT_EXPRESSION_LIST --> ASSIGNMENT_EXPRESSION | ASSIGNMENT_EXPRESSION
	// ',' ARGUMENT_EXPRESSION_LIST
	public ASTMyExpression argument_expression_list() {
		ASTMyExpression argumentExpression = new ASTMyExpression("argumentExpressionList");
		ASTMyExpression assignmentExpression = assignment_expression();
		if (assignmentExpression == null)
			return null;
		argumentExpression.exprs.add(assignmentExpression);
		argumentExpression.children.add(assignmentExpression);

		while (true) {
			ASTToken token = try_matchToken("','");
			if (token != null) {
				argumentExpression.children.add(tokentoMyNode(token));
				ASTMyExpression assignmentExpression2 = assignment_expression();
				if (assignmentExpression2 == null)
					return null;
				argumentExpression.exprs.add(assignmentExpression2);
				argumentExpression.children.add(assignmentExpression2);
			} else
				break;
		}
		return argumentExpression;
	}

	// PRIMARY_EXPRESSION --> IDENTIFIER | CONSTANT | STRING_LITERAL | '('
	// EXPRESSION ')'
	public ASTMyExpression primary_expression() {
		ASTMyExpression primaryExpression = new ASTMyExpression("primaryExpression");
		ScannerToken st = tknList.get(tokenIndex);
		if (st.type.equals("Identifier")) {
			ASTIdentifier identifier = new ASTIdentifier();
			ASTMyNode myNode = new ASTMyNode(st.lexme);
			myNode.setId(tokenIndex);
			identifier.value = st.lexme;
			identifier.tokenId = tokenIndex;
			tokenIndex++;
			identifier.children.add(myNode);
			primaryExpression.children.add(identifier);
			primaryExpression.exprs.add(identifier);
		} else if (st.type.equals("IntegerConstant")) {
			ASTIntegerConstant integerConstant = new ASTIntegerConstant();
			ASTMyNode myNode = new ASTMyNode(st.lexme);
			myNode.setId(tokenIndex);
			integerConstant.value = Integer.parseInt(st.lexme.substring(1, st.lexme.length() - 1));
			integerConstant.tokenId = tokenIndex;
			tokenIndex++;
			integerConstant.children.add(myNode);
			primaryExpression.children.add(integerConstant);
			primaryExpression.exprs.add(integerConstant);
		} else if (st.type.equals("FloatConstant")) {
			ASTFloatConstant floatConstant = new ASTFloatConstant();
			ASTMyNode myNode = new ASTMyNode(st.lexme);
			myNode.setId(tokenIndex);
			floatConstant.value = Double.parseDouble(st.lexme.substring(1, st.lexme.length() - 1));
			floatConstant.tokenId = tokenIndex;
			tokenIndex++;
			floatConstant.children.add(myNode);
			primaryExpression.children.add(floatConstant);
			primaryExpression.exprs.add(floatConstant);
		} else if (st.type.equals("CharConstant")) {
			ASTCharConstant charConstant = new ASTCharConstant();
			ASTMyNode myNode = new ASTMyNode(st.lexme);
			myNode.setId(tokenIndex);
			charConstant.value = st.lexme;
			charConstant.tokenId = tokenIndex;
			tokenIndex++;
			charConstant.children.add(myNode);
			primaryExpression.children.add(charConstant);
			primaryExpression.exprs.add(charConstant);
		} else if (st.type.equals("StringConstant")) {
			ASTStringConstant stringConstant = new ASTStringConstant();
			ASTMyNode myNode = new ASTMyNode(st.lexme);
			myNode.setId(tokenIndex);
			stringConstant.value = st.lexme;
			stringConstant.tokenId = tokenIndex;
			tokenIndex++;
			stringConstant.children.add(myNode);
			primaryExpression.children.add(stringConstant);
			primaryExpression.exprs.add(stringConstant);
		} else if (st.type.equals("'('")) {
			ASTToken token = matchToken("'('");
			primaryExpression.children.add(tokentoMyNode(token));
			ASTMyExpression expression = expression();
			if (expression == null)
				return null;
			primaryExpression.children.add(expression);
			primaryExpression.exprs.add(expression);
			ASTToken token2 = matchToken("')'");
			primaryExpression.children.add(tokentoMyNode(token2));
		} else
			return null;
		return primaryExpression;
	}
}
