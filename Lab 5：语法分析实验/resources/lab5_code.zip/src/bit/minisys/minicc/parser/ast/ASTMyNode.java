package bit.minisys.minicc.parser.ast;

import java.util.ArrayList;
import java.util.List;

public class ASTMyNode extends ASTNode {

	public String specifiedType;
	public List<ASTNode> childNodes;
	private Integer tokenId;

	public ASTMyNode(String type) {
		super(type);
		this.specifiedType = type;
		this.childNodes = new ArrayList<ASTNode>();
	}

	public ASTMyNode(ASTToken token) {
		super(token.value);
		this.specifiedType = token.value;
		tokenId = token.tokenId;
	}

	@Override
	public void accept(ASTVisitor visitor) throws Exception {
		visitor.visit(this);
	}

	public void setId(Integer id) {
		tokenId = id;
	}

	public Integer getId() {
		return tokenId;
	}

	public ASTToken toToken() {
		ASTToken token = new ASTToken(specifiedType, tokenId);
		return token;
	}
}
